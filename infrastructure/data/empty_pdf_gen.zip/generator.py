def lambda_handler(event, context):
    return {
        "isBase64Encoded": False,
        "statusCode": 200,
        "statusDescription": "200 - OK",
        "body": "Lambda Running",
        "headers": {"Content-Type": "text/plain"}
    }